			<div class="header-banner">
					<!-- Top Navigation -->
					<div class="container page-seperator">
					<section class="color bgi">
						<div class="container"> 
						<div class="banneer-text">
						<h3>Premier Cloud Storage.</h3>
						<h4>Giving you what you need.</h4>
							
						<button onclick="$('#features')[0].scrollIntoView(true);" type="button" class="btn btn-warning but1">Learn how</button>
						<p>We provide what the other guys don't: the best cloud storage platform available on the internet. No one beats our product.</p>
						</div>
						<div class="banner-forms">
							<form action="register.php" method="POST">
								<input class="name" type="text" name="username" placeholder="Username">
								<input class="name" type="text" name="firstname" placeholder="First Name">
								<input class="name" type="text" name="lastname" placeholder="Last Name">
								<input class="nuber" type="password" name="password" placeholder="Password">
								<input class="nuber" type="password" name="repassword" placeholder="Confirm Password">
								<button class="btn btn-info mrgn-can">Clear</button>
								<button type="submit" class="btn btn-info mrgn-can">Sign up</button>
							</form>
						</div>
						<div class="clearfix"> </div>
					</section>
					<section class="col-3 ss-style-doublediagonal our-features">
							<div class="container"> 
							<h2 id="features">Our features</h2>
							<p>Providing the world's leading cloud storage features since the beginning.</p>
							<div class="col-md-4 column our-feat">
									<h3>Share Files with Friends</h3>
									<p>We allow you to share your uploads with your friends that also use the service to provide simple and streamlined collaboration.</p>
								</div>
										<div class="col-md-4 column our-feat">
									<h3>Intuitive User Interface</h3>
									<p>All of our users can enjoy our intuitive user interface for uploading and downloading files with ease and simplicity.</p>
								</div>
										<div class="col-md-4 column our-feat">
									<h3>Public Key Management (Beta)</h3>
									<p>We offer a public/private key pair management service to simplify managing multiple key pairs. This service is in beta at this time and is only being offered to our premium members.</p>
								</div>
							</div>
							<div class="clearfix"> </div>
					</section>
					</div>
					</div>
				</div>
